MY TUK TUK - Android Studio project
Designed by Ravindu

Features:
- Offline dashboard with daily and monthly income totals
- Daily hire records: paid or on credit
- Credit hire balances and partial payment updates
- Monthly school hire records and partial payment updates
- Local phone storage; no internet permission or server required

Build an APK:
1. On a computer, install Android Studio.
2. Open this folder as an existing project.
3. Allow Gradle sync (first build may need internet to download Android build tools).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK, normally app/build/outputs/apk/debug/app-debug.apk.

This ZIP contains the Android source project, not a prebuilt APK. Keep separate backups: uninstalling the app or clearing its storage may erase locally saved records.
